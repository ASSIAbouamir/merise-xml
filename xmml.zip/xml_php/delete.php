<?php
session_start();

// Vérifier si l'identifiant est défini dans la requête GET
if (isset($_GET['IDENTIFIANT'])) {
    $id = $_GET['IDENTIFIANT'];

    // Charger le fichier XML
    $users = simplexml_load_file('files/candidats.xml');

    // Initialiser l'indice et le compteur
    $index = -1;
    $i = 0;

    // Parcourir les candidats pour trouver celui avec l'identifiant donné
    foreach ($users->CANDIDAT as $user) {
        if ((string) $user['IDENTIFIANT'] == $id) {
            $index = $i;
            break;
        }
        $i++;
    }

    // Vérifier si l'indice a été trouvé
    if ($index !== -1) {
        // Supprimer le candidat à l'indice trouvé
        unset($users->CANDIDAT[$index]);

        // Sauvegarder les modifications dans le fichier XML
        file_put_contents('files/candidats.xml', $users->asXML());

        $_SESSION['message'] = 'Account deleted successfully';
    } else {
        $_SESSION['message'] = 'Account not found';
    }
} else {
    $_SESSION['message'] = 'Invalid request';
}

// Rediriger vers la page d'index
header('location: index.php');
?>
