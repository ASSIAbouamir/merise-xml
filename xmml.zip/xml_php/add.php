<?php
	session_start();
	if(isset($_POST['add'])){
    // Charger le fichier XML
    $users = simplexml_load_file('files/candidats.xml');

    // Trouver le plus grand identifiant
    $maxId = 0;
    foreach ($users->CANDIDAT as $user) {
        $id = intval($user['IDENTIFIANT']);
        if ($id > $maxId) {
            $maxId = $id;
        }
    }

    // Incrémenter l'identifiant pour le nouveau candidat
    $newId = $maxId + 1;

    // Ajouter un nouveau candidat
    $user = $users->addChild('CANDIDAT');
	    $user->addAttribute('IDENTIFIANT', $newId);
		$user->addAttribute('CIN', $_POST['CIN']);
		$user->addAttribute('CNE', $_POST['CNE']);
		$user->addAttribute('APOGEE', $_POST['APOGEE']);
		$user->addChild('NOM', $_POST['NOM']);
		$user->addChild('PRENOM', $_POST['PRENOM']);
		$user->addChild('EMAIL', $_POST['EMAIL']);
		$user->addChild('MDP', $_POST['MDP']);
		// Save to file
		// file_put_contents('files/members.xml', $users->asXML());
		// Prettify / Format XML and save
		$dom = new DomDocument();
		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;
		$dom->loadXML($users->asXML());
		$dom->save('files/candidats.xml');
		// Prettify / Format XML and save

		$_SESSION['message'] = 'account added successfully';
		header('location: index.php');
	}
	else{
		$_SESSION['message'] = 'Fill up add form first';
		header('location: index.php');
	}

?>

<?php
// session_start();
// if (isset($_POST['add'])) {
//     // Charger le fichier XML
//     $users = simplexml_load_file('files/pxml.xml');
//     $dom = new DomDocument();
//     $dom->loadXML($users->asXML());
    
//     // Convertir XML en tableau
//     $usersArray = [];
//     foreach ($users->children() as $user) {
//         $usersArray[] = $user;
//     }

//     // Créer un nouvel élément candidat
//     $newUser = $dom->createElement('CANDIDAT');
//     $newUser->setAttribute('CIN', $_POST['CIN']);
//     $newUser->setAttribute('CNE', $_POST['CNE']);
//     $newUser->setAttribute('APOGEE', $_POST['APOGEE']);
//     $newUser->appendChild($dom->createElement('NOM', $_POST['NOM']));
//     $newUser->appendChild($dom->createElement('PRENOM', $_POST['PRENOM']));
//     $newUser->appendChild($dom->createElement('EMAIL', $_POST['EMAIL']));
//     $newUser->appendChild($dom->createElement('MDP', $_POST['MDP']));

//     // Insérer le nouvel élément après le dernier candidat
//     array_splice($usersArray, count($usersArray), 0, [$newUser]);

//     // Reconstruire le fichier XML
//     foreach ($usersArray as $item) {
//         $dom->documentElement->appendChild($dom->importNode(dom_import_simplexml($item), true));
//     }

//     // Enregistrer le fichier XML modifié
//     $dom->save('files/pxml.xml');

//     $_SESSION['message'] = 'Member added successfully';
//     header('location: index.php');
// } else {
//     $_SESSION['message'] = 'Fill up add form first';
//     header('location: index.php');
// }
?>
