<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>inscriptions</title>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
    <style>
        .navbar {
            background-color: #333;
            color: white;
            padding: 15px 0;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .navbar a {
            color: white;
            padding: 14px 20px;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s;
            margin: 0 10px;
        }

        .navbar a:hover {
            background-color: #555;
        }
    </style>
</head>

<body>

<div class="navbar">
        <a href="files/result.xml">Diplômes de chaque candidat</a>
        <a href="files/pxml.xml">Candidatures et responsables LPS</a>
        <a href=".">Création des comptes pour candidats</a>
        <a href="files/param.xml">Paramétrage de score</a>
        <a href="files/lpdiploma.xml">LP -> OPTIONS</a>
</div>

<div class="container" style="margin-top: 5%;">
    <h1 class="page-header text-center">Les Candidats</h1>
    <div class="row">
        <div class="col-sm-8 col-sm-offset-2">
            <a href="#addnew" class="btn btn-primary" data-toggle="modal"><span class="glyphicon glyphicon-plus"></span> New</a>
            <?php 
                session_start();
                if(isset($_SESSION['message'])){
                    ?>
                    <div class="alert alert-info text-center" style="margin-top:20px;">
                        <?php echo $_SESSION['message']; ?>
                    </div>
                    <?php

                    unset($_SESSION['message']);
                }
            ?>
            <table class="table table-bordered table-striped" style="margin-top:20px;">
                <thead>
                    <th>NOM</th>
                    <th>PRENOM</th>
                    <th></th>
                    <th>Action</th>
                </thead>
                <tbody>
                    <?php
                    //load xml file
                    $file = simplexml_load_file('files/candidats.xml');

                    // Iterate over each 'CANDIDAT' element
                    foreach ($file->CANDIDAT as $row) {
                        ?>
                        <tr>
                            <td><?php echo $row->NOM; ?></td>
                            <td><?php echo $row->PRENOM; ?></td>
                            <td></td>
                            <td>
                                <a href="#edit_<?php echo $row['IDENTIFIANT']; ?>" data-toggle="modal" class="btn btn-success btn-sm"><span class="glyphicon glyphicon-edit"></span> Edit</a>
                                <a href="#delete_<?php echo $row['IDENTIFIANT']; ?>" data-toggle="modal" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                            </td>
                            <?php include('edit_delete_modal.php'); ?>
                        </tr>
                        <?php
                    }
        
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include('add_modal.php'); ?>
<script src="jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>