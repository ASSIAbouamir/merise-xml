<?php
// Charger le contenu du fichier XML
$xmlString = file_get_contents('files/pxml.xml');
$xml = new SimpleXMLElement($xmlString);

// // Vérifier si des options existent
// if ($xml->BAC_2) {
//     // Commencer la construction de la liste déroulante
//     echo '<select name="maListeDeroulante">';

//     // Utiliser XPath pour obtenir les options sous l'élément BAC_2
//     $options = $xml->xpath('//TYPEDIPL/OPTION');

//     // Parcourir chaque option obtenue avec XPath
//     foreach ($options as $option) {
//         // Utiliser la valeur de l'attribut ID_TYPEDP comme valeur et le texte de l'élément comme libellé
//         $valeur = (string)$option['ID_TYPEDP'];
//         $libelle = (string)$option->LIBELLEOPTION;

//         // Afficher l'option dans la liste déroulante
//         echo '<option value="' . htmlspecialchars($valeur) . '">' . htmlspecialchars($libelle) . '</option>';
//     }

//     // Terminer la liste déroulante
//     echo '</select>';
// } else {
//     // Aucune option n'a été trouvée dans le fichier XML
//     echo 'Aucune option disponible.';
// }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire d'insertion dans un fichier XML</title>
</head>
<body>
    <h1>Formulaire d'insertion dans un fichier XML</h1>

    <form action="traitement.php" method="post">
    <?php
echo '<select name="typeDiplome" id="typeDiplome">';
$optionsTypeDipl = $xml->xpath('//TYPEDIPL');

foreach ($optionsTypeDipl as $typeDipl) {
    $valeur = (string)$typeDipl['ID_TYPEDP'];
    $libelle = (string)$typeDipl->LIBELLE;
    echo '<option value="' . htmlspecialchars($valeur) . '">' . htmlspecialchars($libelle) . '</option>';
}
echo '</select>';

echo '<select name="optionDiplome" id="optionDiplome">';

$optionsOptions = $xml->xpath('//TYPEDIPL/OPTION');
foreach ($optionsOptions as $option) {
    $valeur = (string)$option['ID_OPTION'];
    $libelle = (string)$option->LIBELLEOPTION;
    $idType = (string)$option['ID_TYPEDP'];
    echo '<option value="' . htmlspecialchars($valeur) . '" class="optionType' . htmlspecialchars($idType) . '">' . htmlspecialchars($libelle) . '</option>';
}

echo '</select>';
?>

<script>
document.getElementById('typeDiplome').addEventListener('change', function() {
    // Récupérer la valeur du type sélectionné
    var selectedType = this.value;

    // Masquer toutes les options
    var allOptions = document.querySelectorAll('#optionDiplome option');
    allOptions.forEach(function(option) {
        option.style.display = 'none';
    });

    // Afficher uniquement les options du type sélectionné
    var selectedOptions = document.querySelectorAll('.optionType' + selectedType);
    selectedOptions.forEach(function(option) {
        option.style.display = '';
    });
});
</script>

        <label for="typeDiplome">Type de Diplôme:</label>
        <input type="text" name="typeDiplome" required><br>

        <label for="option">Option:</label>
        <input type="text" name="option" required><br>

        <label for="coefficient">Coefficient:</label>
        <input type="text" name="coefficient" required><br>

        <label for="annee">Année:</label>
        <input type="text" name="annee" required><br>

        <label for="pourcentage">Pourcentage:</label>
        <input type="text" name="pourcentage" required><br>

        <input type="submit" value="Enregistrer">
    </form>
</body>
</html>


