<?php
    session_start();
    if(isset($_POST['edit'])){
        $users = simplexml_load_file('files/candidats.xml');
        $found = false;

        foreach($users->CANDIDAT as $user){
            if((string)$user['IDENTIFIANT'] == $_POST['IDENTIFIANT']){
				$user['CIN'] = $_POST['CIN'];
				$user['CNE'] = $_POST['CNE'];
                $user['APOGEE'] = $_POST['APOGEE'];
                $user->NOM = $_POST['NOM'];
                $user->PRENOM = $_POST['PRENOM'];
                $user->EMAIL = $_POST['EMAIL'];
                $user->MDP = $_POST['MDP'];
                $found = true;
                break;
            }
        }

        if($found){
            file_put_contents('files/candidats.xml', $users->asXML());
            $_SESSION['message'] = 'acc updated successfully';
        } else {
            $_SESSION['message'] = 'acc not found';
        }

        header('location: index.php');
    } else {
        $_SESSION['message'] = 'Select acc to edit first';
        header('location: index.php');
    }
?>
